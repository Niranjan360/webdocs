function createStyle()
{
    let h1 = document.querySelector("h1");
    h1.style.backgroundColor = "black"
    h1.style.borderRadius = "20px"
}
function readStyle()
{
    let h1 = document.querySelector("h1");
    console.log(getComputedStyle(h1).color);
    console.log(getComputedStyle(h1).textAlign);
    // to read a inlinee css only
    console.log( h1.style.color );
}
function updateStyle()
{
    let h1 = document.querySelector("h1");
    h1.style.color = "gold"
}
function deleteStyle()
{
    let h1 = document.querySelector("h1");
    h1.style.color = "black"
    h1.style.backgroundColor = "white"
    h1.borderRadius = "0px";
}