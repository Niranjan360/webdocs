

function applyBorder()
{
    let table = document.querySelector("table");
    let width = document.getElementById("inp1").value;
    let color = document.getElementById("inp2").value;

    // console.log( table.getAttribute("border") );
    // console.log( table.getAttribute("align") );
    table.setAttribute("bordercolor" , color);
    table.setAttribute("border" , width+"px");
}

function applySpace()
{
    let table = document.querySelector("table");
    let cs = document.getElementById("inp3").value;
    let cp = document.getElementById("inp4").value;

    table.setAttribute("cellspacing" , cs+"px");
    table.setAttribute("cellpadding" , cp+"px");
}