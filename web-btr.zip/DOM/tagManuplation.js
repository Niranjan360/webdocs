
function addFoodLast()
{
    let inp = document.querySelector("input");
    let food = inp.value;
    let li = document.createElement("li");
    // li.innerText = food;
    li.textContent = food;
    let ol = document.getElementById("foodlist");
    ol.append(li)
}


function addFoodMiddle()
{
    let food = document.querySelector("#inp1").value;
    let position = document.querySelector("#inp2").value;
    let li = document.createElement("li");
    li.innerText = food;
    let ol = document.getElementById("foodlist");
    let children = ol.children;
    ol.insertBefore(li , children[position-1] );
}


function replaceFood()
{
    let food = document.querySelector("#inp1").value;
    let position = document.querySelector("#inp2").value;
    let li = document.createElement("li");
    li.innerText = food;
    let ol = document.getElementById("foodlist");
    let children = ol.children;
    ol.replaceChild(li , children[position-1]);
}
function removeFood()
{
    let position = document.querySelector("#inp2").value;
    //logic
    let ol = document.getElementById("foodlist");
    let children = ol.children;
    ol.removeChild(children[position-1]);
}