
function placeHolder()
{
    let inp = event.target;
    let label = inp.previousElementSibling;


    if(inp.value != "")
    {
        label.style.color = "rgb(85, 85, 85)"
        label.style.fontSize = "8px";
        label.style.position = "absolute"
        label.style.top = "3px";
        label.style.left = "5px";
    }
    else
    {
        label.style.color = "black"
        label.style.fontSize = "15px";
        label.style.position = "absolute"
        label.style.top = "10px";
        label.style.left = "20px";
    }
}   


function validateForm()
{
    let inp1 = document.getElementById("inp1");
    let inp2 = document.getElementById("inp2");
    let inp3 = document.getElementById("inp3");
    let inp4 = document.getElementById("inp4");
    let inp5 = document.getElementById("inp5");
    let inp6 = document.getElementById("inp6");

    inp1.nextElementSibling.style.display = "none"
    inp2.nextElementSibling.style.display = "none"
    inp3.nextElementSibling.style.display = "none"
    inp4.nextElementSibling.style.display = "none"
    inp5.nextElementSibling.style.display = "none"
    inp6.nextElementSibling.style.display = "none"

    let lower = "qwertyuiopasdfghjklzxcvbnm";
    let upper = "QWERTYUIOPASDFGHJKLZXCVBNM";
    let numbers = "0123456789";
    let special = "!@#$%^&*()"


    if(inp1.value.length<5)
    {
        inp1.nextElementSibling.textContent = "Please type atleast 5 characters"
        inp1.nextElementSibling.style.display = "block"
        return false;
    }

    if(!inp1.value.split("")
    .every((char)=>{return lower.includes(char) || upper.includes(char) || char==" "}) )
    {
        inp1.nextElementSibling.textContent = "Please type only aplhabets"
        inp1.nextElementSibling.style.display = "block"
        return false;
    }


    if(inp2.value.length==0)
    {
        inp2.nextElementSibling.textContent = "Please type email"
        inp2.nextElementSibling.style.display = "block"
        return false;
    }

    if(!inp2.value.endsWith("@gmail.com"))
    {
        inp2.nextElementSibling.textContent = "Please give only gmail account"
        inp2.nextElementSibling.style.display = "block"
        return false;
    }


    if(inp3.value.length!=10)
    {
        inp3.nextElementSibling.textContent = "Please type valid Phone number"
        inp3.nextElementSibling.style.display = "block"
        return false;
    }

    if(!inp3.value.split("").every((d)=>{return d>=0 && d<=9}))
    {
        inp3.nextElementSibling.textContent = "Please give only digits"
        inp3.nextElementSibling.style.display = "block"
        return false;
    }

    if(inp4.value.length<8|| inp4.value.length>16)
    {
        inp4.nextElementSibling.textContent = "Pleasee keep the password between 8-16"
        inp4.nextElementSibling.style.display = "block";
        return false;
    }
    

    let isUpper = inp4.value.split("").some((c)=>{return upper.includes(c)});
    let isLower = inp4.value.split("").some((c)=>{return lower.includes(c)});
    let isNum = inp4.value.split("").some((c)=>{return numbers.includes(c)});
    let isSpecial = inp4.value.split("").some((c)=>{return special.includes(c)});

    if(isUpper==false)
    {
        inp4.nextElementSibling.textContent = "Please keep atleast 1 uppercase"
        inp4.nextElementSibling.style.display = "block";
        return false;
    }
    if(isLower==false)
    {
        inp4.nextElementSibling.textContent = "Please keep atleast 1 Lowercase"
        inp4.nextElementSibling.style.display = "block";
        return false;
    }
    if(isNum==false)
    {
        inp4.nextElementSibling.textContent = "Please keep atleast 1 Number"
        inp4.nextElementSibling.style.display = "block";
        return false;
    }
    if(isSpecial==false)
    {
        inp4.nextElementSibling.textContent = "Please keep atleast 1 special character"
        inp4.nextElementSibling.style.display = "block";
        return false;
    }


    if(inp5.value != inp4.value)
    {
        inp5.nextElementSibling.textContent = " Password missmatch";
        inp5.nextElementSibling.style.display = "block";
        return false;
    }

    let dob = new Date(inp6.value).getFullYear()
    let current = new Date().getFullYear()

    if(current-dob < 18)
    {
        inp6.nextElementSibling.textContent = "your Age should be 18 or more";
        inp6.nextElementSibling.style.display = "block";
        return false;
    }

    // logic to send the data to the database

    return true
}