

function sample()
{
    let ul = document.querySelector("ul");

    // console.log(ul.parentElement);
    // console.log(ul.parentNode);

    // console.log( ul.childNodes );
    // console.log( ul.children );
    // console.log( ul.childElementCount );
    // console.log(ul.firstChild);
    // console.log(ul.firstElementChild);
    // console.log(ul.lastChild);
    // console.log(ul.lastElementChild);
    // console.log( ul.hasChildNodes() );

    // console.log(ul.nextSibling);
    // console.log(ul.nextElementSibling);
    // console.log(ul.previousSibling);
    // console.log(ul.previousElementSibling);

}