

function sample()
{
    // get a single tag 
    let h2 = document.getElementById("head2");
    console.log( h2 );

    // get multiple tags of different type
    let x = document.getElementsByClassName("cls");
    console.log(x);

    // get multiple tags of same type
    let y = document.getElementsByTagName("li");
    console.log( y );

    // get input options
    let z = document.getElementsByName("gender");
    console.log(z);






















    // qury selectors
    // let x = document.querySelector("#head2");
    // console.log(x);

    // let y = document.querySelector(".cls");
    // console.log(y);

    // let z = document.querySelector("li");
    // console.log(z);

    // // ----------------------------------------
    
    // let y1 = document.querySelectorAll(".cls");
    // console.log(y1);

    // let z1 = document.querySelectorAll("li");
    // console.log(z1);

   }


