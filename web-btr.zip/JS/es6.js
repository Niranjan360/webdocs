

// var x = [10,20,30,40,50,60];

// var [a,b,c,...d] = x;

// console.log(a);
// console.log(b);
// console.log(c);
// console.log(d);

/* 
Destructuring 
    It is a process of extracting the values from on structure and storing
    to the indivisual varibales 

Rest operator 
    after Destructuring few values we can take remaing values and store it 
    to another indivisual varibale by using ... rest operator.

    Rest operator will take values , compress and store it into another array.
*/
// add first three elements and keep it in the first position
// function sumOfthree([x,y,z])
// {
//     var sum = x+y+z;
//     console.log(sum);
// }
// var a = [10,20,30,40,50,60];
// sumOfthree(a)

// find the first two max elements in an array
// let a = [32,46,75,46,50,12,37,68,49];
// let [m1 , m2] = a.sort((a,b)=>{ return b-a})
// console.log(m1);
// console.log(m2);


// let a = [10,20];

// let b = [ 0 , ...a , 30 , 40];

// a[0] = 100;
// b[1] = 200;

// console.log(a);

// console.log(b);

// var a = [10,20,30];

// var b = [40,50,60];

// var c = [...a , ...b];

// console.log(c);



// function add(a=0,b=0,c=0,d=0)
// {
//     var sum = a + b + c + d;
//     console.log(sum);
// }
// add(10,20);
// min aurgumnet

// let a = [10,20,30,40,50];

// a.push(60,70,80,90,200,220);

// console.log(a);


// function sample(...a)
// {
//     console.log(a);
// }
// sample()
// sample(10)
// sample(10,20,30)
// sample(10,20,30,40,50,60)



// function checkAge(na


// function addFirstTwo([v1,v2])
// {
//     let sum = v1+v2;
//     console.log(sum);
// }
// addFirstTwo( [10,20,30,40,50] )




// var a = [10,20,30];

// var b = [...a , 40,50 ];

// a[0] = 100;

// b[1] = 200;

// console.log(a);

// console.log(b);


// var a = [10,20,30,40,50,60];

// console.log( a.slice() );



// default parameter 
// WHAT : assigning a default values for function parameter
// WHY  : to make our functions to accept a minimum number of aurguments
// function add(a=0,b=0,c=0,d=0)
// {
//     var sum = a*b*c*d;
//     console.log(sum);
// }
// add(10,20);


// var a = [10,20,30,40,50,60];
// function slice(start=0 , end=a.length)
// {
//     let newArr = [];
//     for (let i = start; i < end; i++) 
//     {
//         newArr.push(a[i]);
//     }
//     return newArr;
// }
// console.log( slice() );


// Rest parameter
// WHAT : If we use rest operator for funtion parameter then it's called rest parameter
// WHY  :  whenever we need to accept maximum number of arguments.

// function sample(...a)
// {
//     console.log(a);
// }
// sample(10,20,30,40,50)

// var a = [10,20,30,40,50,60];

// function push(...items)
// {
//     for (let i = 0; i < items.length; i++) 
//     {
//         a[a.length] = items[i];    
//     }
// }
// push(70,80,90)

// console.log(a);

// console.log(1);

// console.log(2);

// setTimeout(()=>{console.log(3);} , 3000)

// console.log(4);


