// function database()
// {
//     let products = [    
//         {brand:"puma" , item:"shirt"},
//         {brand:"nike" , item:"shirt"},
//         {brand:"puma" , item:"tracks"},
//         {brand:"nike" , item:"caps"},
//         {brand:"reebok" , item:"shirt"},
//         {brand:"puma" , item:"tee"},
//         {brand:"reebok" , item:"shirt"},
//         {brand:"puma" , item:"shoes"},
//         {brand:"reebok" , item:"shirt"},
//     ];
//     return products;
// }










// // PRODUCING CODE : TAKES TIME TO EXECUTE AND RETURN
// function backend(req) // puma
// {
//     let products = database();
//     return new Promise((res,rej)=>{ 
//         setTimeout(()=>{
//             if( products.some((v,i,a)=>{return v.brand==req}) )
//             {
//                 res( products.filter((v,i,a)=>{return v.brand==req}) )
//             }
//             else
//             {
//                 rej("No data found")
//             }
//         } , 5000)
//      })
// }









// // CONSUMING CODE : SHOULD WAIT FOR RESULT
// // function frontend(product)
// // {   
// //     let promiseResult = backend(product);

// //     promiseResult
// //     .then((data)=>{console.log(data);})
// //     .catch((err)=>{console.log(err);})
// // }
// // frontend("reebok");

// async function frontend(product)
// {   
//     try{
//         let data = await backend(product);
//         console.log(data);
//     }
//     catch(err)
//     {
//         console.log(err);
//     }
// }
// frontend("coma");






// let x = setInterval( ()=>{
//             console.log( new Date().toLocaleTimeString() );
//         } , 1000)

// setTimeout(()=>{
//     clearInterval(x);
// } , 10000)


// function database()
// {
//     let movies = [
//         {moviename:"KGF" , genre:"action" , hero:"yash"},
//         {moviename:"Kantara" , genre:"action" , hero:"rishab"},
//         {moviename:"bahubali" , genre:"action" , hero:"prabhas"},
//         {moviename:"pushpa" , genre:"action" , hero:"allu arjun"},
//     ]
//     return movies;
// }
// function backend(searchkey)
// {
//     let movies = database();
//     return new Promise((resolve , reject)=>{
//         setTimeout(()=>{
//             let filterdData = movies.filter((v)=>{return v.moviename.toLowerCase().includes(searchkey.toLowerCase())})
//             if(filterdData.length!=0){
//                 resolve(filterdData);
//             }
//             else{
//                 reject("No movies found !!")
//             }
//         } , 5000)
//     })
// }
// async function frontend(searchkey)
//     {
//         try{
//             let result = await backend(searchkey);
//             console.log(result);
//         }
//         catch(error){
//             console.log(error);
//         }
//     }
// frontend("avngrs")



console.log(1);
console.log(2);
function producing()
{
    return new Promise((resolve,reject)=>{
        setTimeout(()=>{
            resolve(3);
        } , 5000)
    })
}
function consuming()
{
   let promiseResult = producing();
   promiseResult.then((val)=>{
                        console.log(val);
                        console.log(4);
                    })
}
consuming()