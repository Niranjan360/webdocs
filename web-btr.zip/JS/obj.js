
// let products = [
//                     {product : "TV" , items : 4},
//                     {product : "AC" , items : 10},
//                     {product : "FRIDGE" , items : 1},
//                     {product : "TV" , items : 8},
//                     {product : "AC" , items : 4},
//                     {product : "RADIO" , items : 3},
//                     {product : "RADIO" , items : 7},
//                     {product : "AC" , items : 7},
//                     {product : "TV" , items : 5},
//             ]

// function createObj()
// {
//     let p = {}
//     for (let i = 0; i < products.length; i++) 
//     {
//         let key =  products[i].product;
//         if( p[key]==undefined )
//         {
//             p[key] = products[i].items;
//         }
//         else
//         {
//             p[key] = p[key] + products[i].items;
//         }
//     }
//     console.log(p);
// }
// createObj();




// MAPS in JS

let m = new Map();

m.set("x" , 10)
m.set('y' , "hello")
m.set('z' , true)

// console.log( m.get('x') );
// console.log( m.get('y') );
// console.log( m.get('z') );

// console.log(m.size);

// console.log(m.has("x"));
// console.log(m.has("x1"));

// m.delete("z");
// m.clear();
// let k =  m.keys() 
// let v = m.values()
// m.forEach((v,k,m)=>{console.log(v);})

// SET 

// let s = new Set();
// s.add(10);
// s.add("hello");
// s.add(false);
// s.add(20);
// s.add(true);

// let k = s.values()
// let j = k.next();
// while( !j.done )
// {
//     console.log( j.value );
//     j = k.next();
// }

// s.forEach((val,key,s)=>{console.log(s);})



class Parent
{
    constructor(v1)
    {
        this.v1 = v1;
    }
    m1() 
    {
        console.log("this is m1 method");
    }
}

class Child extends Parent
{
    constructor(v1,v2)
    {
        super(v1)
        this.v2 = v2;
    }
    m2() 
    {
        console.log("this is m2 method");
    }
}

class Child2 extends Parent
{
    constructor(v1,v22)
    {
        super(v1)
        this.v22 = v22;
    }
    m22() 
    {
        console.log("this is m22 method");
    }
}


class GrandChild extends Child 
{
    constructor(v1,v2,v3)
    {
        super(v1,v2)
        this.v3 = v3;
    }
    m3() 
    {
        console.log("this is m3 method");
    }
}
let c1 = new GrandChild(10,20,30);



console.log( c1.v1 );
console.log( c1.v2 );
console.log( c1.v3 );

c1.m1();
c1.m2();
c1.m3();
