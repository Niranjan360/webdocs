var a = 10;

var b = "heloo"
var c = true;
var d;
var e = [10,20];
var f = {f1:100 , f2:200}
var g = ()=>{console.log("this is fn");}

export {b,c};
export default a;
