
// let a = [11,21,34,46,52];

// for(let val of a)
// {
//     if(val%2==0)
//         console.log(val);
// }

// let b = {b1:100,b2:200,b3:300,b4:400,b5:500};

// for(let key in b)
// {
//     console.log( b[key] );
// }


// // copy by value & copy by Reference
// var a = 10;
// var b = a ;   // it is premitive data so value is copied

// a = 20;

// console.log(a);  // 20
// console.log(b);  // 10

// ///////////////////////////////////

// var x = {x1 :10 , x2:20};
// var y = x;    // it is a non-premitive data so address is copied

// x.x1 = 100;
// console.log(x);  // {x1:100 , x2:20}
// console.log(y);  // {x1:100 , x2:20}

// // the problem while copying non-premitive data's is changes done for one will affect another one also


// to exract values and to store into indivisual variables
// let a = [10,20,30,40,50,60];

// let [x,y,...z] = a;

// console.log(x);
// console.log(y);
// console.log(z);

// let b = {color:"red",price:1000,desc:"sample",
//          ram:"16gb" , brand:"hp"}


// let {color:lc,brand:lb,...obj} = b;

// console.log(lc);
// console.log(lb);
// console.log(obj);

function database()
{   
    // size 6mb
    let products = [
        {pname:"black shoe" , picURL:"http",price:1000,color:"red"},
        {pname:"red shoe" , picURL:"http",price:1200,color:"red"},
        {pname:"white shoe" , picURL:"http",price:1500,color:"red"},
        {pname:"black shoe" , picURL:"http",price:1000,color:"red"},
        {pname:"red shoe" , picURL:"http",price:1200,color:"red"},
        {pname:"white shoe" , picURL:"http",price:1500,color:"red"},
    ]
    return products;
}

function backend()
{
    let products = database();
    for (let i = 0; i < products.length; i++) 
    {
        fe(products[i])        
    }
}
backend()


function fe({pname})
{
    // display the data
    console.log(pname);
    console.log("consumed 1/6 mb");
};


