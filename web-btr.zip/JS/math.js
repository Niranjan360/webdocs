
// console.log( Math.PI );

// console.log( Math.sqrt(25) );
// console.log( Math.cbrt(27) );
// console.log( Math.pow(3,3) );
// console.log( Math.abs(10) );
// console.log(  Math.max(10,20,30,40,50,60) );
// console.log(  Math.min(10,20,30,40,50) );
// console.log( Math.random() );
// console.log( Math.round(10.5) );
// console.log( Math.floor(10.9999) );
// console.log( Math.ceil(10.0001) );
// console.log( Math.trunc(10.1) );
// console.log( Math.sign(-10));




 

// let n = ()=>{ return Math.floor(Math.random()*10)};

// function generateOtp()
// {
//     return ""+ n() + n() + n () + n() + n();
// }
// console.log( generateOtp() );

// function captcha()
// {
//     // generates random number from 0-25
//     let r1 = ()=>{ return Math.floor(Math.random()*26)};

//     // generates random number from 0-9
//     let r2 = ()=>{ return Math.floor(Math.random()*10)};

//     let u = "QWERTYUIOPASDFGHJKLZXCVBNM";
//     let l = "qwertyuiopasdfghjkzxcvbnm"
//     let s = ")(*&^%$#@!"

//     return r2() + u[r1()] + l[r1()] + r2() + s[r2()] + u[r1()];
// }
// console.log(captcha());
// console.log(captcha());
// console.log(captcha());
// console.log(captcha());

 
// function dice()
// {
//     return Math.ceil(Math.random() * 6);
// }
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());
// console.log(dice());

