import x from './index2.js'
import {b,c} from './index2.js'

console.log( x );

console.log( b );
console.log( c );



