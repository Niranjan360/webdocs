var a = 10;

function b()
{
    var x = 20;
    console.log(x);
}

console.log(a);
b()
console.log(x);