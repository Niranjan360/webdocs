
// Date 

// 1) current date and time 

    // let d1 = new Date();
    // console.log(d1);

// 2) perticular date and time 

    // let d2 = new Date(2023,0,1,5,30,0,0);
    // console.log(d2);

// date object meethods 

// let d1 = new Date();
// IST FOMATS
// console.log( d1.getFullYear() );
// console.log( d1.getMonth() );
// console.log( d1.getDate() );
// console.log( d1.getDay() );
// console.log( d1.getHours() );
// console.log( d1.getMinutes() );
// console.log( d1.getSeconds() );
// console.log( d1.getMilliseconds() );

// // UTC FORMATS
// console.log( d1.getUTCFullYear() );
// console.log( d1.getUTCMonth() );
// console.log( d1.getUTCDate() );
// console.log( d1.getUTCDay() );
// console.log( d1.getUTCHours() );
// console.log( d1.getUTCMinutes() );
// console.log( d1.getUTCSeconds() );
// console.log( d1.getUTCMilliseconds() );


// IST
// d1.setFullYear(2000);
// d1.setMonth(0);
// d1.setDate(1);
// d1.setHours(6);
// d1.setMinutes(0);
// d1.setSeconds(0);
// d1.setMilliseconds(0);

//utc
// d1.setUTCFullYear(2000);
// d1.setUTCMonth(0);
// d1.setUTCDate(1);
// d1.setUTCHours(6);
// d1.setUTCMinutes(0);
// d1.setUTCSeconds(0);
// d1.setUTCMilliseconds(0);

// console.log( d1.toString() );
// console.log( d1.toDateString() );
// console.log( d1.toTimeString() );
// console.log("------------------");
// console.log( d1.toLocaleString() );
// console.log( d1.toLocaleDateString() );
// console.log( d1.toLocaleTimeString() );


// let d1 = new Date(2020,10,10,6,0,0,0);
// let d2 = new Date(2020,10,11,6,0,0,0);

// console.log( d2 > d1 );
// console.log( d1 > d2 );

// let products = [
//                 {pname:"tshirt" , addedOn : "2020/10/6"},
//                 {pname:"trousers" , addedOn : "2021/3/16"},
//                 {pname:"watches" , addedOn : "2023/4/12"},
//                 {pname:"caps" , addedOn : "2021/10/13"},
//                 {pname:"shirts" , addedOn : "2022/11/24"},
//                 {pname:"tshirt" , addedOn : "2022/10/3"},
//                 {pname:"shoes" , addedOn : "2021/5/9"},
//                 {pname:"sandals" , addedOn : "2020/6/16"},
//             ]
// function sort()
// {
//     for (let i = 0; i < products.length; i++) 
//     {
//         for (let j = i+1; j < products.length; j++) 
//         {
//             if( new Date(products[i].addedOn) < new Date(products[j].addedOn))
//             {
//                 let temp = products[i];
//                 products[i] = products[j];
//                 products[j] = temp;
//             }
//         }
//     }
//     console.log(products);
// }
// sort()